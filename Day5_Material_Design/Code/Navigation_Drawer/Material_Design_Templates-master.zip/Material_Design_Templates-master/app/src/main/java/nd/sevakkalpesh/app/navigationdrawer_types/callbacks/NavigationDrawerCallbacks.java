package nd.sevakkalpesh.app.navigationdrawer_types.callbacks;

/**
 * Created by Kalpesh on 18/2/2015.
 */
public interface NavigationDrawerCallbacks {
    void onNavigationDrawerItemSelected(int position);
}
