package info.androidhive.slidingmenu;

import info.androidhive.slidingmenu.adapter.NavDrawerListAdapter;
import info.androidhive.slidingmenu.model.NavDrawerItem;

import java.util.ArrayList;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {
	private DrawerLayout mDrawerLayout;
	private ListView mDrawerListLtR;
	private ListView mDrawerListRtL;
	private ActionBarDrawerToggle mDrawerToggleLtR;
	private ActionBarDrawerToggle mDrawerToggleRtL;

	// nav drawer title
	private CharSequence mDrawerTitle;

	// used to store app title
	private CharSequence mTitle;

	// slide menu items
	private String[] navMenuTitlesLtR;
	private String[] navMenuTitlesRtL;
	private TypedArray navMenuIcons;

	private ArrayList<NavDrawerItem> navDrawerItemsLtR;
	private ArrayList<NavDrawerItem> navDrawerItemsRtL;
	private NavDrawerListAdapter adapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		mTitle = mDrawerTitle = getTitle();

		// load slide menu items
		navMenuTitlesLtR = getResources().getStringArray(
				R.array.nav_drawer_items);

		// nav drawer icons from resources
		navMenuIcons = getResources()
				.obtainTypedArray(R.array.nav_drawer_icons);

		mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
		mDrawerLayout.openDrawer(Gravity.END);
		mDrawerLayout.closeDrawer(Gravity.END);

		mDrawerListLtR = (ListView) findViewById(R.id.list_slidermenuLtR);

		mDrawerListRtL = (ListView) findViewById(R.id.list_slidermenuRtL);

		navDrawerItemsLtR = new ArrayList<NavDrawerItem>();

		// adding nav drawer items to array
		// Home
		navDrawerItemsLtR.add(new NavDrawerItem(navMenuTitlesLtR[0],
				navMenuIcons.getResourceId(0, -1)));
		// Find People
		navDrawerItemsLtR.add(new NavDrawerItem(navMenuTitlesLtR[1],
				navMenuIcons.getResourceId(1, -1)));
		// Photos
		navDrawerItemsLtR.add(new NavDrawerItem(navMenuTitlesLtR[2],
				navMenuIcons.getResourceId(2, -1)));
		// Communities, Will add a counter here
		navDrawerItemsLtR.add(new NavDrawerItem(navMenuTitlesLtR[3],
				navMenuIcons.getResourceId(3, -1), true, "22"));
		// Pages
		navDrawerItemsLtR.add(new NavDrawerItem(navMenuTitlesLtR[4],
				navMenuIcons.getResourceId(4, -1)));
		// What's hot, We will add a counter here
		navDrawerItemsLtR.add(new NavDrawerItem(navMenuTitlesLtR[5],
				navMenuIcons.getResourceId(5, -1), true, "50+"));
		navDrawerItemsLtR.add(new NavDrawerItem(navMenuTitlesLtR[6],
				navMenuIcons.getResourceId(6, -1), true, "1"));

		navMenuTitlesRtL = getResources().getStringArray(
				R.array.nav_drawer_rtl_items);
		navMenuIcons = getResources().obtainTypedArray(
				R.array.nav_drawer_rtl_icons);
		navDrawerItemsRtL = new ArrayList<NavDrawerItem>();

		navDrawerItemsRtL.add(new NavDrawerItem(navMenuTitlesRtL[0],
				navMenuIcons.getResourceId(0, -1)));
		// Find People
		navDrawerItemsRtL.add(new NavDrawerItem(navMenuTitlesRtL[1],
				navMenuIcons.getResourceId(1, -1)));
		// Photos
		navDrawerItemsRtL.add(new NavDrawerItem(navMenuTitlesRtL[2],
				navMenuIcons.getResourceId(2, -1)));
		// Communities, Will add a counter here
		navDrawerItemsRtL.add(new NavDrawerItem(navMenuTitlesRtL[3],
				navMenuIcons.getResourceId(3, -1)));
		// Pages
		navDrawerItemsRtL.add(new NavDrawerItem(navMenuTitlesRtL[4],
				navMenuIcons.getResourceId(4, -1)));
		// What's hot, We will add a counter here
		navDrawerItemsRtL.add(new NavDrawerItem(navMenuTitlesRtL[5],
				navMenuIcons.getResourceId(5, -1)));

		// Recycle the typed array
		navMenuIcons.recycle();

		mDrawerListLtR.setOnItemClickListener(new SlideMenuLtRClickListener());
		mDrawerListRtL.setOnItemClickListener(new SlideMenuRtLClickListener());

		// setting the nav drawer list adapter
		adapter = new NavDrawerListAdapter(getApplicationContext(),
				navDrawerItemsLtR);
		mDrawerListLtR.setAdapter(adapter);

		adapter = new NavDrawerListAdapter(getApplicationContext(),
				navDrawerItemsRtL);
		mDrawerListRtL.setAdapter(adapter);

		// enabling action bar app icon and behaving it as toggle button
		getActionBar().setDisplayHomeAsUpEnabled(true);
		getActionBar().setHomeButtonEnabled(true);

		mDrawerToggleLtR = new ActionBarDrawerToggle(this, mDrawerLayout,
				R.drawable.ic_drawer, // nav menu toggle icon
				R.string.menuLtR, // nav drawer open - description for
									// accessibility
				R.string.menuLtR // nav drawer close - description for
									// accessibility
		) {
			public void onDrawerClosed(View view) {
				getActionBar().setTitle(mTitle);
				// calling onPrepareOptionsMenu() to show action bar icons
				invalidateOptionsMenu();
			}

			public void onDrawerOpened(View drawerView) {
				getActionBar().setTitle(mDrawerTitle);
				// calling onPrepareOptionsMenu() to hide action bar icons
				invalidateOptionsMenu();
			}
		};

		mDrawerToggleRtL = new ActionBarDrawerToggle(this, mDrawerLayout,
				R.drawable.ic_drawer, // nav menu toggle icon
				R.string.menuRtL, // nav drawer open - description for
									// accessibility
				R.string.menuRtL // nav drawer close - description for
									// accessibility
		) {
			public void onDrawerClosed(View view) {
				getActionBar().setTitle(mTitle);
				// calling onPrepareOptionsMenu() to show action bar icons
				invalidateOptionsMenu();
			}

			public void onDrawerOpened(View drawerView) {
				getActionBar().setTitle(mDrawerTitle);
				// calling onPrepareOptionsMenu() to hide action bar icons
				invalidateOptionsMenu();
			}

			@Override
			public boolean onOptionsItemSelected(MenuItem item) {
				if (item != null && item.getItemId() == android.R.id.home) {
					if (mDrawerLayout.isDrawerOpen(Gravity.RIGHT)) {
						mDrawerLayout.closeDrawer(Gravity.RIGHT);
					} else {
						mDrawerLayout.openDrawer(Gravity.RIGHT);
					}
				}
				return false;
			}
		};

		mDrawerLayout.setDrawerListener(mDrawerToggleLtR);

		if (savedInstanceState == null) {
			// on first time display view for first nav item
			displayViewLtR(0);
		}
	}

	/**
	 * Slide menu item click listener
	 * */
	private class SlideMenuLtRClickListener implements
			ListView.OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			// display view for selected nav drawer item
			displayViewLtR(position);
		}
	}

	/**
	 * Slide menu item click listener
	 * */
	private class SlideMenuRtLClickListener implements
			ListView.OnItemClickListener {
		@Override
		public void onItemClick(AdapterView<?> parent, View view, int position,
				long id) {
			// display view for selected nav drawer item
			displayViewRtL(position);
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// getMenuInflater().inflate(R.menu.main, menu);
		getMenuInflater().inflate(R.menu.rtl, menu);

		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// toggle nav drawer on selecting action bar app icon/title
		if (mDrawerToggleLtR.onOptionsItemSelected(item)) {
			mDrawerLayout.closeDrawer(mDrawerListRtL);
			return true;
		}
		// Handle action bar actions click
		switch (item.getItemId()) {
		case R.id.btn_rtl:
			if (mDrawerLayout.isDrawerOpen(mDrawerListRtL)) {
				mDrawerLayout.closeDrawer(mDrawerListRtL);
			} else {
				mDrawerLayout.closeDrawer(mDrawerListLtR);
				mDrawerLayout.openDrawer(mDrawerListRtL);
			}
		default:
			return super.onOptionsItemSelected(item);
		}
	}

	/* *
	 * Called when invalidateOptionsMenu() is triggered
	 */
	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		// if nav drawer is opened, hide the action items
		boolean drawerOpen = mDrawerLayout.isDrawerOpen(mDrawerListLtR);
		// menu.findItem(R.id.option1).setVisible(!drawerOpen);
		return super.onPrepareOptionsMenu(menu);
	}

	/**
	 * Diplaying fragment view for selected nav drawer list item
	 * */
	private void displayViewLtR(int position) {
		// update the main content by replacing fragments
		Fragment fragment = null;
		switch (position) {
		case 0:
			fragment = new HomeFragment();
			break;
		case 1:
			fragment = new FindPeopleFragment();
			break;
		case 2:
			fragment = new PhotosFragment();
			break;
		case 3:
			fragment = new CommunityFragment();
			break;
		case 4:
			fragment = new PagesFragment();
			break;
		case 5:
			fragment = new WhatsHotFragment();
			break;

		default:
			break;
		}

		if (fragment != null) {
			FragmentManager fragmentManager = getFragmentManager();
			fragmentManager.beginTransaction()
					.replace(R.id.frame_container, fragment).commit();

			// update selected item and title, then close the drawer
			mDrawerListLtR.setItemChecked(position, true);
			mDrawerListLtR.setSelection(position);
			setTitle(navMenuTitlesLtR[position]);
			mDrawerLayout.closeDrawer(mDrawerListLtR);
		} else {
			// error in creating fragment
			Log.e("MainActivity", "Error in creating fragment");
		}
	}

	private void displayViewRtL(int position) {
		// update the main content by replacing fragments
		Fragment fragment = null;
		switch (position) {
		case 0:
			fragment = new SpicyPizzaFragment();
			break;
		case 1:
			fragment = new BeefBurgerFragment();
			break;
		case 2:
			fragment = new ChickenPizzaFragment();
			break;
		case 3:
			fragment = new ChickenBurgerFragment();
			break;
		case 4:
			fragment = new FishBurgerFragment();
			break;
		case 5:
			fragment = new MangoJuiceFragment();
			break;

		default:
			break;
		}

		if (fragment != null) {
			FragmentManager fragmentManager = getFragmentManager();
			fragmentManager.beginTransaction()
					.replace(R.id.frame_container, fragment).commit();

			// update selected item and title, then close the drawer
			mDrawerListRtL.setItemChecked(position, true);
			mDrawerListRtL.setSelection(position);
			setTitle(navMenuTitlesRtL[position]);
			mDrawerLayout.closeDrawer(mDrawerListRtL);
		} else {
			// error in creating fragment
			Log.e("MainActivity", "Error in creating fragment");
		}
	}

	@Override
	public void setTitle(CharSequence title) {
		mTitle = title;
		getActionBar().setTitle(mTitle);
	}

	/**
	 * When using the ActionBarDrawerToggle, you must call it during
	 * onPostCreate() and onConfigurationChanged()...
	 */

	@Override
	protected void onPostCreate(Bundle savedInstanceState) {
		super.onPostCreate(savedInstanceState);
		// Sync the toggle state after onRestoreInstanceState has occurred.
		mDrawerToggleLtR.syncState();
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		// Pass any configuration change to the drawer toggls
		mDrawerToggleLtR.onConfigurationChanged(newConfig);
	}

}
